﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Orchard.Recipes.Services
{
    public class DefaultRecipeManager : IRecipeManager
    {
        public string Execute(Models.Recipe recipe)
        {
            return string.Empty;
        }
    }
}
